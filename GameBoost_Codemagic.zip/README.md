# GameBoost

Native Android project for Android 10+.

## Build with Codemagic
The parent repository uses a `codemagic.yaml` workflow to unpack this source archive and build a debug APK.

Package: `com.gameboost.app`
Min SDK: 29
Target SDK: 35
