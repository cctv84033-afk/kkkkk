package com.gameboost.app

import android.telecom.Call
import android.telecom.CallScreeningService

class GameCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val incoming = callDetails.callDirection == Call.Details.DIRECTION_INCOMING
        val gameMode = getSharedPreferences("gameboost", MODE_PRIVATE)
            .getBoolean("game_mode", false)

        if (incoming && gameMode) {
            val response = CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(true)
                .build()

            respondToCall(callDetails, response)
        } else {
            respondToCall(callDetails, CallResponse.Builder().build())
        }
    }
}
