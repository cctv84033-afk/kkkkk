package com.gameboost.app

import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val prefsName = "gameboost"
    private val gameModeKey = "game_mode"
    private val requestCallRole = 9001

    private lateinit var gameModeStatus: TextView
    private lateinit var callRoleStatus: TextView
    private lateinit var gameModeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fontPanel = findViewById<LinearLayout>(R.id.fontPanel)
        val boostPanel = findViewById<LinearLayout>(R.id.boostPanel)

        findViewById<Button>(R.id.fontButton).setOnClickListener {
            fontPanel.visibility = View.VISIBLE
            boostPanel.visibility = View.GONE
        }

        findViewById<Button>(R.id.boostButton).setOnClickListener {
            fontPanel.visibility = View.GONE
            boostPanel.visibility = View.VISIBLE
            refreshGameModeUi()
            refreshCallRoleUi()
        }

        gameModeStatus = findViewById(R.id.gameModeStatus)
        gameModeButton = findViewById(R.id.gameModeButton)
        callRoleStatus = findViewById(R.id.callRoleStatus)

        gameModeButton.setOnClickListener {
            val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            val newValue = !prefs.getBoolean(gameModeKey, false)
            prefs.edit().putBoolean(gameModeKey, newValue).apply()
            refreshGameModeUi()
        }

        findViewById<Button>(R.id.callRoleButton).setOnClickListener {
            requestCallScreeningRole()
        }

        findViewById<Button>(R.id.searchFontButton).setOnClickListener {
            showFontResults()
        }

        refreshGameModeUi()
        refreshCallRoleUi()
    }

    override fun onResume() {
        super.onResume()
        refreshCallRoleUi()
    }

    private fun refreshGameModeUi() {
        val enabled = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .getBoolean(gameModeKey, false)

        gameModeStatus.text = if (enabled) "ON — INCOMING CALLS BLOCKED" else "OFF"
        gameModeButton.text = if (enabled) "DEACTIVATE GAME MODE" else "ACTIVATE GAME MODE"
    }

    private fun refreshCallRoleUi() {
        val roleManager = getSystemService(RoleManager::class.java)
        val held = roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
        callRoleStatus.text =
            if (held) "Call Screening role: ENABLED" else "Call Screening role: not enabled"
    }

    private fun requestCallScreeningRole() {
        val roleManager = getSystemService(RoleManager::class.java)
        if (roleManager != null &&
            roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        ) {
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
            startActivityForResult(intent, requestCallRole)
        }
    }

    private fun showFontResults() {
        val input = findViewById<EditText>(R.id.fontInput)
        val results = findViewById<LinearLayout>(R.id.fontResults)
        val text = input.text.toString().trim()

        results.removeAllViews()
        if (text.isEmpty()) return

        val styles = listOf(
            text,
            text.map(::fullWidth).joinToString(""),
            text.map(::circled).joinToString(""),
            text.map(::doubleStruck).joinToString("")
        )

        styles.forEachIndexed { index, styled ->
            val item = TextView(this).apply {
                this.text = styled
                textSize = 22f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(14, 18, 14, 18)
                setOnClickListener { copyToClipboard(styled) }
            }
            results.addView(item)
        }
    }

    private fun copyToClipboard(value: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("GameBoost Font", value))
    }

    private fun fullWidth(c: Char): Char {
        return when (c) {
            in '!'..'~' -> (c.code + 0xFEE0).toChar()
            ' ' -> '\u3000'
            else -> c
        }
    }

    private fun circled(c: Char): Char {
        return when {
            c in 'A'..'Z' -> (0x24B6 + (c - 'A')).toChar()
            c in 'a'..'z' -> (0x24D0 + (c - 'a')).toChar()
            c in '1'..'9' -> (0x2460 + (c - '1')).toChar()
            c == '0' -> '⓪'
            else -> c
        }
    }

    private fun doubleStruck(c: Char): Char {
        val upper = "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ"
        return if (c in 'A'..'Z') upper[c - 'A'] else c
    }
}
